# -*- coding: utf-8 -*-
'''
CV PDF Generator
-------

This plugin takes a rendered HTML page, and generates a single PDF from it. Not intended to compete with the pelican-pdf plugin.
'''

from weasyprint import HTML, CSS
from pelican import signals
from pelican.generators import Generator

import os
import logging

logger = logging.getLogger(__name__)


class PdfGenerator(Generator):
#     "Generate PDFs on the output dir, for all articles and pages"
#
#     supported_md_fields = ['date']
#
    def __init__(self, *args, **kwargs):
        super(PdfGenerator, self).__init__(*args, **kwargs)

        if 'HTML_PATH' in self.settings and 'PDF_OUTPUT_NAME' in self.settings:
            if '.pdf' not in self.settings['PDF_OUTPUT_NAME']:
                self.settings['PDF_OUTPUT_NAME'] = self.settings['PDF_OUTPUT_NAME'] + '.pdf'

            if not os.path.isfile('./output/' + self.settings['HTML_PATH']):
                logger.error('The HTML file to read doesn\'t seem to exist in that spot')

    def generate_output(self, writer=None):
            HTML('./output/' + self.settings['HTML_PATH']).write_pdf('./output/'+self.settings['PDF_OUTPUT_NAME'], presentational_hints=True)


def get_generators(generators):
    return PdfGenerator


def register():
    signals.get_generators.connect(get_generators)
